#pragma once

using namespace System;

public ref class Client {
public:
	int id;
	String^ clientName;
	String^ clientType;
};