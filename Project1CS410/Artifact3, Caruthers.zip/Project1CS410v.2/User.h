#pragma once

using namespace System;

public ref class User {
public:
	int id;
	String^ username;
	String^ password;
};