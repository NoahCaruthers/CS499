package com.example.myapplication;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;


public class InventoryDisplay extends AppCompatActivity {


    private DBHandler dbHandler;
    private RecyclerView recyclerView;
    private Button add_button;
    ArrayList<String> item_id, item_name, item_description, item_quantity;
    MyAdapter myAdapter;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.recyclerview);

        //links local variable to global attributes
        dbHandler = new DBHandler(InventoryDisplay.this);

        item_id = new ArrayList<>();
        item_name = new ArrayList<>();
        item_description = new ArrayList<>();
        item_quantity = new ArrayList<>();

        storeDataInArrays();

        myAdapter = new MyAdapter(InventoryDisplay.this, item_id, item_name, item_description, item_quantity );
        recyclerView.setAdapter(myAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(InventoryDisplay.this));

        add_button = findViewById(R.id.addItem);

        //listens for click to open functions
        add_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent  = new Intent(InventoryDisplay.this, AddToActivity.class);
                startActivity(intent);
            }
        });
    }

    private void storeDataInArrays(){
        Cursor cursor = dbHandler.readAllData();

        while(cursor.moveToNext()){
            item_id.add(cursor.getString(0));
            item_name.add(cursor.getString(1));
            item_description.add(cursor.getString(2));
            item_quantity.add(cursor.getString(3));
        }
    }

    public static class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder>{

        private Context context;
        private ArrayList<String> item_id, item_name, item_description, item_quantity;

        MyAdapter(Context context, ArrayList item_id, ArrayList item_name, ArrayList item_description, ArrayList item_quantity){
            this.context = context;
            this.item_id = item_id;
            this.item_name = item_name;
            this.item_description = item_description;
            this.item_quantity = item_quantity;
        }
        @NonNull
        @Override
        public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            LayoutInflater inflater = LayoutInflater.from(context);
            View view = inflater.inflate(R.layout.recycler_row, parent, false);
            return new MyViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull MyViewHolder holder, int position){
            holder.item_id.setText(String.valueOf(item_id.get(position)));
            holder.item_name.setText(String.valueOf(item_name.get(position)));
            holder.item_description.setText(String.valueOf(item_description.get(position)));
            holder.item_quantity.setText(String.valueOf(item_quantity.get(position)));
        }

        @Override
        public int getItemCount() {
            return item_id.size();
        }



        public class MyViewHolder extends RecyclerView.ViewHolder {

            TextView item_id, item_name, item_description, item_quantity;

            public MyViewHolder(@NonNull View itemView){
                super(itemView);
                item_id = itemView.findViewById(R.id.item_id);
                item_name = itemView.findViewById(R.id.item_name);
                item_description = itemView.findViewById(R.id.item_description);
                item_quantity = itemView.findViewById(R.id.item_quantity);
            }
        }

    }
}
