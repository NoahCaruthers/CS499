package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.CompoundButton;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;


public class SMSNotif extends AppCompatActivity {

    private CheckBox smsCheck, smsnoCheck;
    private DBHandler dbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.smsnotif);

        smsCheck = findViewById(R.id.checkBox);
        smsnoCheck = findViewById(R.id.noCheck);

        dbHandler = new DBHandler(SMSNotif.this);

        //checks to see if sms box checked yes
        smsCheck.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if (isChecked){
                    // sends user to inventory display
                    Intent intent  = new Intent(getApplicationContext(), InventoryDisplay.class);
                    startActivity(intent);

                    // notify user of low on hand
                    dbHandler.getLowQty();
                }
            }
        });
        //checks to see if sms box checked no
        smsnoCheck.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if (isChecked){

                    // sends user to inventory display
                    Intent intent  = new Intent(getApplicationContext(), InventoryDisplay.class);
                    startActivity(intent);

                }
            }
        });

    }

}
