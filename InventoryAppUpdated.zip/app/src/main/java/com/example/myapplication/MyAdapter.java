package com.example.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder>{

    private Context context;
    private ArrayList<String> item_id, item_name, item_description, item_quantity;

    MyAdapter(Context context, ArrayList item_id, ArrayList item_name, ArrayList item_description, ArrayList item_quantity){
        this.context = context;
        this.item_id = item_id;
        this.item_name = item_name;
        this.item_description = item_description;
        this.item_quantity = item_quantity;
    }
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.recycler_row, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position){
        holder.item_id.setText(String.valueOf(item_id.get(position)));
        holder.item_name.setText(String.valueOf(item_name.get(position)));
        holder.item_description.setText(String.valueOf(item_description.get(position)));
        holder.item_quantity.setText(String.valueOf(item_quantity.get(position)));
    }

    @Override
    public int getItemCount() {
        return item_id.size();
    }



    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView item_id, item_name, item_description, item_quantity;

        public MyViewHolder(@NonNull View itemView){
            super(itemView);
            item_id = itemView.findViewById(R.id.item_id);
            item_name = itemView.findViewById(R.id.item_name);
            item_description = itemView.findViewById(R.id.item_description);
            item_quantity = itemView.findViewById(R.id.item_quantity);
        }
    }

}
