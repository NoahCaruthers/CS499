package com.example.projectappnoahcaruthers;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.SimpleCursorAdapter;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;


public class InventoryDisplay extends AppCompatActivity {

    private GridView gridView;
    private DBHandler dbHandler;
    private Button otherScreen, upDateItemCount, deleteItem;
    private EditText textName, textQty;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.inventorydisplay);

        dbHandler = new DBHandler(InventoryDisplay.this);
        gridView = findViewById(R.id.gridView);
        otherScreen = findViewById(R.id.additemscreen);


        otherScreen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent  = new Intent(getApplicationContext(), AddToActivity.class);
                startActivity(intent);
            }
        });

        displayInventory();
    }
    private void displayInventory(){
        SQLiteDatabase db = dbHandler.getReadableDatabase();
        Cursor cursor = db.query("inventory", null, null, null, null,null,null);

        String[] fromCol = {"name","description",  "quantity"};
        int[] toViews = {R.id.itemName,R.id.description, R.id.qty};

        SimpleCursorAdapter adapter = new SimpleCursorAdapter(this, R.layout.grid_item, cursor, fromCol, toViews, 0);
        gridView.setAdapter(adapter);
    }

}
