package com.example.projectappnoahcaruthers;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.Intent;

public class MainActivity extends AppCompatActivity {

    private Button newAccountButton, loginButton;
    private EditText usernameEdit, passwordEdit;
    private DBHandler dbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.login_screen);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;

        });

        usernameEdit = findViewById(R.id.editUsername);
        passwordEdit = findViewById(R.id.editPassword);
        newAccountButton = findViewById(R.id.newAccount);
        loginButton = findViewById(R.id.buttonLogin);

        dbHandler = new DBHandler(MainActivity.this);

        newAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userName = usernameEdit.getText().toString();
                String userPassword = passwordEdit.getText().toString();


                if (userName.isEmpty() || userPassword.isEmpty()){
                    Toast.makeText(MainActivity.this, "Please enter all data.", Toast.LENGTH_SHORT).show();
                    return;
                }
                dbHandler.addNewUser(userName, userPassword);

                Toast.makeText(MainActivity.this, "User has been added.", Toast.LENGTH_SHORT).show();
                usernameEdit.setText("");
                passwordEdit.setText("");
            }
        });
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String userName = usernameEdit.getText().toString();
                String userPassword = passwordEdit.getText().toString();

                if (userName.isEmpty() || userPassword.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter all data.", Toast.LENGTH_SHORT).show();
                    return;
                }
                Boolean checkUser = dbHandler.checkUser(userName, userPassword);

                if(checkUser != Boolean.FALSE){
                    Toast.makeText(MainActivity.this, "User Verified.", Toast.LENGTH_SHORT).show();
                    Intent intent  = new Intent(getApplicationContext(), SMSNotif.class);
                    startActivity(intent);
                }
                else{
                    Toast.makeText(MainActivity.this, "Invalid Login.", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }
}

