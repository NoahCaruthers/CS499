package com.example.projectappnoahcaruthers;

import android.content.Intent;
import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.CompoundButton;


import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;


public class SMSNotif extends AppCompatActivity {

    private CheckBox smsCheck, smsnoCheck;
    private DBHandler dbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.smsnotif);

        smsCheck = findViewById(R.id.checkBox);
        smsnoCheck = findViewById(R.id.noCheck);

        dbHandler = new DBHandler(SMSNotif.this);

        smsCheck.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if (isChecked){
                    Intent intent  = new Intent(getApplicationContext(), InventoryDisplay.class);
                    startActivity(intent);

                    dbHandler.getLowQty();
                }
            }
        });
        smsnoCheck.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if (isChecked){

                    Intent intent  = new Intent(getApplicationContext(), InventoryDisplay.class);
                    startActivity(intent);

                }
            }
        });

    }

}
