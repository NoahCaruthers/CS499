package com.example.projectappnoahcaruthers;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class AddToActivity extends AppCompatActivity {

    private Button itemButton, otherScreen, upDateItemCount, deleteItem;
    private EditText itemNameEdit, itemDescriptionEdit, itemQtyEdit;
    private DBHandler dbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.addtoscreen);

        itemNameEdit = findViewById(R.id.editItemName);
        itemDescriptionEdit = findViewById(R.id.editItemDescription);
        itemQtyEdit = findViewById(R.id.editItemQty);
        itemButton = findViewById(R.id.addItemButton);
        otherScreen = findViewById(R.id.inventoryButton);
        upDateItemCount = findViewById(R.id.updateButton);
        deleteItem = findViewById(R.id.deleteButton);

        dbHandler = new DBHandler(AddToActivity.this);

        otherScreen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent  = new Intent(getApplicationContext(), InventoryDisplay.class);
                startActivity(intent);
            }
        });
        upDateItemCount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String itemName = itemNameEdit.getText().toString();
                String itemQty = itemQtyEdit.getText().toString();
                dbHandler.updateItem(itemName, itemQty);
                Intent intent  = new Intent(getApplicationContext(), InventoryDisplay.class);
                startActivity(intent);
            }
        });
        deleteItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String itemName = itemNameEdit.getText().toString();
                dbHandler.deleteItem(itemName);
                Intent intent  = new Intent(getApplicationContext(), InventoryDisplay.class);
                startActivity(intent);
            }
        });

        itemButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String itemName = itemNameEdit.getText().toString();
                String itemDescription = itemDescriptionEdit.getText().toString();
                String itemQuantity = itemQtyEdit.getText().toString();

                if (itemName.isEmpty() || itemDescription.isEmpty() || itemQuantity.isEmpty()){
                    Toast.makeText(AddToActivity.this, "Please enter all data.", Toast.LENGTH_SHORT).show();
                    return;
                }
                dbHandler.addNewItem(itemName, itemDescription, Float.parseFloat(itemQuantity));

                Toast.makeText(AddToActivity.this, "Item has been added.", Toast.LENGTH_SHORT).show();
                itemNameEdit.setText("");
                itemDescriptionEdit.setText("");
                itemQtyEdit.setText("");
            }
        });


    }

}
