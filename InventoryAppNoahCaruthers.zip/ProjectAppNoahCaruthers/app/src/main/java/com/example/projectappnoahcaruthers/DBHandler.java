package com.example.projectappnoahcaruthers;

import static android.content.ContentValues.TAG;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;


public class DBHandler extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "inventory.db";
    private static final int VERSION = 1;

    public DBHandler(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class InventoryTable {
        private static final String TABLE = "inventory";
        private static final String COL_ID = "_id";
        private static final String COL_NAME = "name";
        private static final String COL_DESCRIPTION = "description";
        private static final String COL_QTY = "quantity";
    }

    private static final class UserTable{
        private static final String TABLE = "users";
        private static final String COL_ID = "_id";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + InventoryTable.TABLE + " (" +
                InventoryTable.COL_ID + " integer primary key autoincrement, " +
                InventoryTable.COL_NAME + " text, " +
                InventoryTable.COL_DESCRIPTION + " text, " +
                InventoryTable.COL_QTY + " text)");

        db.execSQL("create table " + UserTable.TABLE + " (" +
                UserTable.COL_ID + " integer primary key autoincrement, " +
                UserTable.COL_USERNAME + " text, " +
                UserTable.COL_PASSWORD + " float)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " +InventoryTable.TABLE);
        onCreate(db);
    }

    public void addNewItem(String itemName, String itemDescription, float itemQty){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(InventoryTable.COL_NAME,itemName );
        values.put(InventoryTable.COL_DESCRIPTION, itemDescription);
        values.put(InventoryTable.COL_QTY, itemQty);

        db.insert(InventoryTable.TABLE, null, values);
        db.close();
    }

    public void addNewUser(String userName, String userPassword){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(UserTable.COL_USERNAME,userName );
        values.put(UserTable.COL_PASSWORD, userPassword);

        db.insert(UserTable.TABLE, null, values);
        db.close();
    }
    public Boolean checkUser(String userName, String userPassword){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(UserTable.TABLE, null, UserTable.COL_USERNAME + " =?", new String[]{userName}, null, null, null);

        if(cursor.moveToFirst()) {
            @SuppressLint("Range")
            String storedPassword = cursor.getString(cursor.getColumnIndex(UserTable.COL_PASSWORD));
            return userPassword.equals(storedPassword);
        }
        cursor.close();
        return Boolean.FALSE;
    }
    public void getLowQty(){
        SQLiteDatabase db = this.getReadableDatabase();

        String qty = "1";

        Cursor cursor = db.query(InventoryTable.COL_NAME,null,InventoryTable.COL_QTY + " =?",new String[]{qty},null, null, null);
        if(cursor.moveToFirst()){
            do{
                String name = cursor.getString(1);
                Log.d(TAG, "Low on hand of " + name );
            }while (cursor.moveToNext());
        }
    }
    public void deleteItem(String itemName) {
        SQLiteDatabase db = this.getWritableDatabase();

        db.delete(InventoryTable.TABLE, InventoryTable.COL_NAME + " LIKE ?", new String[]{itemName});
    }
    public void updateItem(String itemName, String itemQty){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(InventoryTable.COL_NAME, itemName);

        db.update(InventoryTable.TABLE, values, InventoryTable.COL_QTY + " LIKE ?", new String[]{itemQty});

    }
}
